/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 19. Process (thread) synchronization using mutex locks: shared counter
 */
/* Process (thread) synchronization using mutex locks: shared counter */
#include <stdio.h>
#include <pthread.h>
#define THREADS 4
#define LOOPS 100000
long counter = 0; pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;
void *work(void *a){ (void)a;
    for (int i = 0; i < LOOPS; i++) { pthread_mutex_lock(&lock); counter++; pthread_mutex_unlock(&lock); }
    return NULL;
}
int main(void){
    pthread_t t[THREADS];
    for (int i = 0; i < THREADS; i++) pthread_create(&t[i], NULL, work, NULL);
    for (int i = 0; i < THREADS; i++) pthread_join(t[i], NULL);
    printf("Threads            : %d\nIncrements/thread  : %d\n", THREADS, LOOPS);
    printf("Expected counter   : %d\nActual counter     : %ld\n", THREADS * LOOPS, counter);
    printf("%s\n", counter == THREADS * LOOPS ? "Result correct: mutex prevented the race condition." : "Race condition!");
    return 0;
}
