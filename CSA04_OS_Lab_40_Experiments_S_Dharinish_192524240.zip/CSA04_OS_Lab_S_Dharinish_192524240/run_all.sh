#!/usr/bin/env bash
# Compile and run every experiment, showing its output
for d in Exp*/; do
  n=$(echo "$d" | sed 's/Exp\([0-9]*\)_.*/\1/')
  echo "=================== $d ==================="
  ( cd "$d" && gcc -std=gnu11 -Wall -Wextra -pthread exp$n.c -o exp$n && ./exp$n; rm -f exp$n )
done
