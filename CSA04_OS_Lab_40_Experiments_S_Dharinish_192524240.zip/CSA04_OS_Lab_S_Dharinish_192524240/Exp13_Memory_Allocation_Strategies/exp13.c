/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 13. Memory allocation strategies: First Fit, Best Fit and Worst Fit compared
 */
/* Memory allocation strategies: First Fit, Best Fit and Worst Fit compared */
#include <stdio.h>
#include <string.h>
#define NB 5
#define NP 4
static void run(const char *name, int mode){
    int blk[NB] = {100, 500, 200, 300, 600}, proc[NP] = {212, 417, 112, 426};
    printf("--- %s ---\n", name);
    int frag = 0;
    for (int p = 0; p < NP; p++) {
        int s = -1;
        for (int b = 0; b < NB; b++) {
            if (blk[b] < proc[p]) continue;
            if (s < 0 || (mode == 1 && blk[b] < blk[s]) || (mode == 2 && blk[b] > blk[s])) s = b;
            if (mode == 0 && s >= 0) break;
        }
        if (s >= 0) { blk[s] -= proc[p]; printf("P%d (%d KB) -> Block %d, left %d KB\n", p+1, proc[p], s+1, blk[s]); }
        else printf("P%d (%d KB) -> Not allocated\n", p+1, proc[p]);
    }
    for (int b = 0; b < NB; b++) frag += blk[b];
    printf("Total free memory left in blocks = %d KB\n\n", frag);
}
int main(void){
    run("First Fit", 0); run("Best Fit", 1); run("Worst Fit", 2);
    return 0;
}
