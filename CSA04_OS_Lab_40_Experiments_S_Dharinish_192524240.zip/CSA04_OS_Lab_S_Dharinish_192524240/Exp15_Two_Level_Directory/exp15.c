/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 15. Two-level directory: a master directory with one sub-directory per user
 */
/* Two-level directory: a master directory with one sub-directory per user */
#include <stdio.h>
#include <string.h>
#define U 3
#define F 5
char user[U][12] = {"alice", "bob", "carol"};
char files[U][F][16]; int cnt[U];
int uid(const char *u){ for (int i = 0; i < U; i++) if (!strcmp(user[i], u)) return i; return -1; }
void create(const char *u, const char *f){
    int x = uid(u); if (x < 0) { printf("no such user %s\n", u); return; }
    for (int i = 0; i < cnt[x]; i++) if (!strcmp(files[x][i], f)) { printf("%s/%s : already exists\n", u, f); return; }
    strcpy(files[x][cnt[x]++], f); printf("%s/%s : created\n", u, f);
}
void search(const char *u, const char *f){
    int x = uid(u);
    for (int i = 0; x >= 0 && i < cnt[x]; i++) if (!strcmp(files[x][i], f)) { printf("search %s/%s : found\n", u, f); return; }
    printf("search %s/%s : not found\n", u, f);
}
void del(const char *u, const char *f){
    int x = uid(u);
    for (int i = 0; x >= 0 && i < cnt[x]; i++) if (!strcmp(files[x][i], f)) {
        for (int j = i; j < cnt[x]-1; j++) strcpy(files[x][j], files[x][j+1]);
        cnt[x]--; printf("%s/%s : deleted\n", u, f); return; }
    printf("delete %s/%s : not found\n", u, f);
}
void show(void){
    printf("\nMaster directory:\n");
    for (int i = 0; i < U; i++) {
        printf("  [%s] ->", user[i]);
        for (int j = 0; j < cnt[i]; j++) printf(" %s", files[i][j]);
        printf("\n");
    }
}
int main(void){
    create("alice", "notes.txt"); create("alice", "a.c"); create("bob", "notes.txt");
    create("bob", "data.csv"); create("carol", "report.doc"); create("alice", "a.c");
    show(); search("bob", "notes.txt"); search("carol", "notes.txt");
    del("alice", "a.c"); show();
    return 0;
}
