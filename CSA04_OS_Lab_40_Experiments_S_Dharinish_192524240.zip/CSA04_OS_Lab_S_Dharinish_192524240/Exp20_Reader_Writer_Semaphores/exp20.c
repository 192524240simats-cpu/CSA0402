/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 20. Readers-Writers problem (readers preference) using semaphores
 */
/* Readers-Writers problem (readers preference) using semaphores */
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
sem_t wrt, mutex, out; int readcount = 0, data = 0;
void say(const char *s, int id, int v){ sem_wait(&out); printf("%s %d %s %d\n", s, id, "-> data =", v); fflush(stdout); sem_post(&out); }
void *reader(void *a){ int id = *(int *)a; usleep(120000 * id);
    sem_wait(&mutex); if (++readcount == 1) sem_wait(&wrt); sem_post(&mutex);
    say("Reader", id, data); usleep(200000);
    sem_wait(&mutex); if (--readcount == 0) sem_post(&wrt); sem_post(&mutex);
    return NULL; }
void *writer(void *a){ int id = *(int *)a; usleep(150000 * id);
    sem_wait(&wrt); data += 10; say("Writer", id, data); usleep(200000); sem_post(&wrt);
    return NULL; }
int main(void){
    pthread_t r[3], w[2]; int ri[3] = {1,2,3}, wi[2] = {1,2};
    sem_init(&wrt, 0, 1); sem_init(&mutex, 0, 1); sem_init(&out, 0, 1);
    for (int i = 0; i < 3; i++) pthread_create(&r[i], NULL, reader, &ri[i]);
    for (int i = 0; i < 2; i++) pthread_create(&w[i], NULL, writer, &wi[i]);
    for (int i = 0; i < 3; i++) pthread_join(r[i], NULL);
    for (int i = 0; i < 2; i++) pthread_join(w[i], NULL);
    printf("Final data = %d\n", data);
    return 0;
}
