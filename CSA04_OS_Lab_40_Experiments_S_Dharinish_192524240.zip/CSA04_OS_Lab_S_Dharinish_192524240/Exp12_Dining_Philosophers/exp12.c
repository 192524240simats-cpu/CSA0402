/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 12. 
 */
/* Dining philosophers: 5 philosophers, 5 chopsticks (mutexes),
   a semaphore admits at most 4 to the table so deadlock cannot occur. */
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#define N 5
pthread_mutex_t chop[N], out = PTHREAD_MUTEX_INITIALIZER;
sem_t room;
void say(int i, const char *s){ pthread_mutex_lock(&out); printf("Philosopher %d %s\n", i+1, s); fflush(stdout); pthread_mutex_unlock(&out); }
void *phil(void *a){
    int i = *(int *)a;
    for (int r = 0; r < 2; r++) {
        say(i, "is thinking");  usleep(100000 * (i + 1));
        say(i, "is hungry");
        sem_wait(&room);
        pthread_mutex_lock(&chop[i]);
        pthread_mutex_lock(&chop[(i+1)%N]);
        say(i, "is eating");    usleep(150000);
        pthread_mutex_unlock(&chop[(i+1)%N]);
        pthread_mutex_unlock(&chop[i]);
        sem_post(&room);
    }
    say(i, "has finished");
    return NULL;
}
int main(void){
    pthread_t t[N]; int id[N];
    sem_init(&room, 0, N-1);
    for (int i = 0; i < N; i++) pthread_mutex_init(&chop[i], NULL);
    for (int i = 0; i < N; i++) { id[i] = i; pthread_create(&t[i], NULL, phil, &id[i]); }
    for (int i = 0; i < N; i++) pthread_join(t[i], NULL);
    printf("All philosophers have eaten; no deadlock.\n");
    return 0;
}
