/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 28. Simulation of the UNIX 'grep' command: plain, -n (line numbers), -i (ignore case), -c (count), -v (invert)
 */
/* Simulation of the UNIX 'grep' command: plain, -n (line numbers), -i (ignore case), -c (count), -v (invert) */
#include <stdio.h>
#include <string.h>
#include <ctype.h>
static char *ci_strstr(const char *h, const char *n){
    for (; *h; h++) { const char *a = h, *b = n; while (*a && *b && tolower((unsigned char)*a) == tolower((unsigned char)*b)) { a++; b++; } if (!*b) return (char *)h; }
    return NULL;
}
static void grep(const char *file, const char *pat, int n, int i, int c, int v){
    FILE *f = fopen(file, "r"); char line[256]; int ln = 0, cnt = 0;
    while (fgets(line, sizeof line, f)) {
        ln++; int m = (i ? ci_strstr(line, pat) : strstr(line, pat)) != NULL;
        if (v) m = !m;
        if (!m) continue;
        cnt++;
        if (!c) { if (n) printf("%d:", ln); printf("%s", line); }
    }
    if (c) printf("%d\n", cnt);
    fclose(f);
}
int main(int argc, char **argv){
    if (argc >= 3) { grep(argv[2], argv[1], 1, 0, 0, 0); return 0; }
    FILE *f = fopen("sample.txt", "w");
    fputs("Operating systems manage hardware.\nLinux is an operating system kernel.\nA process is a program in execution.\nThe scheduler selects the next process.\nMemory is managed using paging.\n", f);
    fclose(f);
    printf("$ grep \"process\" sample.txt\n");        grep("sample.txt", "process", 0, 0, 0, 0);
    printf("\n$ grep -n \"operating\" sample.txt\n"); grep("sample.txt", "operating", 1, 0, 0, 0);
    printf("\n$ grep -i \"OPERATING\" sample.txt\n"); grep("sample.txt", "OPERATING", 0, 1, 0, 0);
    printf("\n$ grep -c \"process\" sample.txt\n");   grep("sample.txt", "process", 0, 0, 1, 0);
    printf("\n$ grep -v \"process\" sample.txt\n");   grep("sample.txt", "process", 0, 0, 0, 1);
    remove("sample.txt");
    return 0;
}
