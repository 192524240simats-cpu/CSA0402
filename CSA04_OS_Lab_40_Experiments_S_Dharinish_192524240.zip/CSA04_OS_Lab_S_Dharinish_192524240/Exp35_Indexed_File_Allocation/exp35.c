/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 35. Indexed file allocation: one index block holds pointers to all data blocks of the file
 */
/* Indexed file allocation: one index block holds pointers to all data blocks of the file */
#include <stdio.h>
#define BLOCKS 30
int used[BLOCKS];
int main(void){
    int preused[] = {1, 4, 5, 9, 10, 15, 16, 22}; for (int i = 0; i < 8; i++) used[preused[i]] = 1;
    int need = 5;                                   /* data blocks wanted by the file */
    int index = -1, data[16], n = 0;
    for (int b = 0; b < BLOCKS && index < 0; b++) if (!used[b]) index = b;
    used[index] = 1;
    for (int b = 12; b < BLOCKS && n < need; b++) if (!used[b]) { used[b] = 1; data[n++] = b; }   /* scattered placement */
    printf("File 'results.dat' needs %d data blocks\n", need);
    printf("Index block chosen: %d\n\nIndex block %d contents:\n", index, index);
    for (int i = 0; i < n; i++) printf("  entry %d -> block %d\n", i, data[i]);
    int want = 3;
    printf("\nDirect access to logical block %d: look at entry %d of index block %d -> physical block %d\n", want, want, index, data[want]);
    printf("Blocks in use after allocation:");
    for (int b = 0; b < BLOCKS; b++) if (used[b]) printf(" %d", b);
    printf("\n");
    return 0;
}
