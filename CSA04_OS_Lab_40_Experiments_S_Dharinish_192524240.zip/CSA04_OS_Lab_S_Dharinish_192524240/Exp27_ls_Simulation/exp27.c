/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 27. Simulation of the UNIX 'ls' command (ls and ls -l) using opendir/readdir/stat
 */
/* Simulation of the UNIX 'ls' command (ls and ls -l) using opendir/readdir/stat */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
static int cmp(const void *a, const void *b){ return strcmp(*(char *const *)a, *(char *const *)b); }
static void perms(mode_t m, char *s){
    s[0] = S_ISDIR(m) ? 'd' : '-'; const char *r = "rwxrwxrwx";
    for (int i = 0; i < 9; i++) s[i+1] = (m & (1 << (8 - i))) ? r[i] : '-';
    s[10] = 0;
}
static void myls(const char *dir, int longfmt){
    DIR *d = opendir(dir); if (!d) { perror(dir); return; }
    char *list[64]; int n = 0; struct dirent *e;
    while ((e = readdir(d))) if (e->d_name[0] != '.') list[n++] = strdup(e->d_name);
    closedir(d); qsort(list, n, sizeof *list, cmp);
    for (int i = 0; i < n; i++) {
        if (!longfmt) { printf("%s  ", list[i]); continue; }
        char p[512], pm[11]; struct stat st;
        snprintf(p, sizeof p, "%s/%s", dir, list[i]); stat(p, &st); perms(st.st_mode, pm);
        printf("%s %ld %6ld %s\n", pm, (long)st.st_nlink, (long)st.st_size, list[i]);
    }
    if (!longfmt) printf("\n");
    for (int i = 0; i < n; i++) free(list[i]);
}
int main(int argc, char **argv){
    if (argc > 1) { myls(argv[1], 1); return 0; }
    mkdir("ls_demo", 0755); mkdir("ls_demo/docs", 0755);
    const char *f[] = {"ls_demo/readme.txt", "ls_demo/main.c", "ls_demo/run.sh"}; int sz[] = {120, 450, 60}; mode_t md[] = {0644, 0644, 0755};
    for (int i = 0; i < 3; i++) { int fd = open(f[i], O_WRONLY|O_CREAT|O_TRUNC, md[i]); for (int k = 0; k < sz[i]; k++) write(fd, "x", 1); close(fd); chmod(f[i], md[i]); }
    printf("$ ls ls_demo\n"); myls("ls_demo", 0);
    printf("\n$ ls -l ls_demo\n"); myls("ls_demo", 1);
    for (int i = 0; i < 3; i++) unlink(f[i]);
    rmdir("ls_demo/docs"); rmdir("ls_demo");
    return 0;
}
