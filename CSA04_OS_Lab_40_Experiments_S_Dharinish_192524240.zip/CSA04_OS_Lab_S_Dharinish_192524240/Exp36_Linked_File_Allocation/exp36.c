/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 36. Linked file allocation: blocks scattered on disk, each block holds a pointer to the next
 */
/* Linked file allocation: blocks scattered on disk, each block holds a pointer to the next */
#include <stdio.h>
#define BLOCKS 30
int next[BLOCKS], used[BLOCKS];
struct { int first, last, len; } dir;
int main(void){
    int preused[] = {2, 3, 7, 8, 12, 13, 14, 20}; for (int i = 0; i < 8; i++) used[preused[i]] = 1;
    int want[] = {9, 16, 1, 25, 11}, n = 5;          /* scattered free blocks chosen for the file */
    for (int i = 0; i < BLOCKS; i++) next[i] = -1;
    for (int i = 0; i < n; i++) { used[want[i]] = 1; if (i) next[want[i-1]] = want[i]; }
    dir.first = want[0]; dir.last = want[n-1]; dir.len = n;
    printf("Directory entry: file='report'  first block=%d  last block=%d  length=%d blocks\n\n", dir.first, dir.last, dir.len);
    printf("Block\tPointer to next block\n");
    for (int b = dir.first, i = 0; b != -1; b = next[b], i++)
        if (next[b] >= 0) printf("%d\t-> %d\n", b, next[b]); else printf("%d\t-> NULL (end of file)\n", b);
    printf("\nSequential read order: ");
    for (int b = dir.first; b != -1; b = next[b]) printf("%d%s", b, next[b] >= 0 ? " -> " : "\n");
    printf("To reach the 4th block we must follow %d pointers from the first block.\n", 3);
    return 0;
}
