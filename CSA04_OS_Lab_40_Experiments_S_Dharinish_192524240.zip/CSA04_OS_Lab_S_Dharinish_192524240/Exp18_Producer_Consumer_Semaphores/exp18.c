/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 18. Producer-consumer (bounded buffer, size 3) using counting semaphores + mutex
 */
/* Producer-consumer (bounded buffer, size 3) using counting semaphores + mutex */
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#define SIZE 3
#define ITEMS 6
int buf[SIZE], in = 0, out = 0;
sem_t empty, full; pthread_mutex_t m = PTHREAD_MUTEX_INITIALIZER;
void *producer(void *a){ (void)a;
    for (int i = 1; i <= ITEMS; i++) {
        sem_wait(&empty); pthread_mutex_lock(&m);
        buf[in] = i * 10; printf("Producer produced %d at slot %d\n", buf[in], in); fflush(stdout);
        in = (in + 1) % SIZE;
        pthread_mutex_unlock(&m); sem_post(&full); usleep(100000);
    }
    return NULL;
}
void *consumer(void *a){ (void)a;
    for (int i = 1; i <= ITEMS; i++) {
        sem_wait(&full); pthread_mutex_lock(&m);
        printf("                         Consumer consumed %d from slot %d\n", buf[out], out); fflush(stdout);
        out = (out + 1) % SIZE;
        pthread_mutex_unlock(&m); sem_post(&empty); usleep(250000);
    }
    return NULL;
}
int main(void){
    pthread_t p, c;
    sem_init(&empty, 0, SIZE); sem_init(&full, 0, 0);
    pthread_create(&p, NULL, producer, NULL); pthread_create(&c, NULL, consumer, NULL);
    pthread_join(p, NULL); pthread_join(c, NULL);
    printf("All %d items produced and consumed.\n", ITEMS);
    return 0;
}
