/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 33. Optimal page replacement
 */
/* Optimal page replacement */
#include <stdio.h>
#define N 20
int main(void){
    int ref[N] = {7,0,1,2,0,3,0,4,2,3,0,3,2,1,2,0,1,7,0,1};
    int F = 3, fr[3] = {-1,-1,-1}, last[3] = {0}, load[3] = {0}, faults = 0;
    printf("Reference string: "); for (int i = 0; i < N; i++) printf("%d ", ref[i]);
    printf("\nFrames = %d\n\nPage\tFrames\t\tFault\n", F);
    for (int i = 0; i < N; i++) {
        int hit = -1;
        for (int j = 0; j < F; j++) if (fr[j] == ref[i]) hit = j;
        if (hit >= 0) last[hit] = i;
        else {
            int v = -1;
            for (int j = 0; j < F; j++) if (fr[j] == -1) { v = j; break; }
            if (v < 0) {
                int far = -1; for (int j = 0; j < F; j++) { int k; for (k = i+1; k < N; k++) if (ref[k] == fr[j]) break; if (k > far) { far = k; v = j; } }
            }
            fr[v] = ref[i]; last[v] = i; load[v] = i; (void)load[v]; (void)last[v]; faults++;
        }
        printf("%d\t", ref[i]);
        for (int j = 0; j < F; j++) { if (fr[j] < 0) printf("- "); else printf("%d ", fr[j]); }
        printf("\t%s\n", hit >= 0 ? "hit" : "FAULT");
    }
    printf("\nTotal page faults = %d\nHit ratio = %.2f\n", faults, (float)(N - faults) / N);
    return 0;
}
