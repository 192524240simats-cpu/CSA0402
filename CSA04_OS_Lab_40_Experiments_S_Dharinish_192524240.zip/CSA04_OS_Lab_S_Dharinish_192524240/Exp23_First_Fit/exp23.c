/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 23. First Fit memory allocation (blocks shrink after allocation)
 */
/* First Fit memory allocation (blocks shrink after allocation) */
#include <stdio.h>
int main(void){
    int nb = 5, np = 4;
    int blk[] = {100, 500, 200, 300, 600}, orig[5];
    int proc[] = {212, 417, 112, 426}, alloc[4];
    for (int i = 0; i < nb; i++) orig[i] = blk[i];
    for (int p = 0; p < np; p++) {
        int s = -1; alloc[p] = -1;
        for (int b = 0; b < nb; b++) {
            if (blk[b] < proc[p]) continue;
            if (s < 0) s = b;
        }
        if (s >= 0) { alloc[p] = s; blk[s] -= proc[p]; }
    }
    printf("Memory blocks: ");
    for (int i = 0; i < nb; i++) printf("%d ", orig[i]);
    printf("\nProcess\tSize\tBlock\tRemaining in block\n");
    for (int p = 0; p < np; p++) {
        if (alloc[p] >= 0) printf("P%d\t%d\tB%d\t%d\n", p+1, proc[p], alloc[p]+1, blk[alloc[p]]);
        else printf("P%d\t%d\tNot allocated\t-\n", p+1, proc[p]);
    }
    return 0;
}
