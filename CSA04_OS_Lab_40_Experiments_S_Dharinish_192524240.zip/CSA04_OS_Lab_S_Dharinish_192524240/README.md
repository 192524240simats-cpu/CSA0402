# CSA04 – Operating Systems Lab (40 Experiments)

**Name:** S Dharinish  **Register No:** 192524240

| Item | Value |
|---|---|
| OS | Ubuntu 24.04 LTS |
| Compiler | gcc 13.3.0 |
| Compile command | `gcc -std=gnu11 -Wall -Wextra -pthread expNN.c -o expNN` |

Every experiment has its own folder containing the C source (`expNN.c`) and its real program output (`output.txt`).
All programs compile with **zero warnings** and use built-in sample data (no keyboard input needed).

## Run one experiment
```bash
cd Exp01_Process_IDs
gcc -std=gnu11 -Wall -Wextra -pthread exp01.c -o exp01
./exp01
```
## Run all experiments
```bash
bash run_all.sh
```

## Index
| No. | Experiment | CO |
|---|---|---|
| 1 | Process creation, PID and PPID (fork, getpid, getppid) | CO1 |
| 2 | File copy using system calls | CO1 |
| 3 | FCFS CPU scheduling | CO2 |
| 4 | Scheduling: smallest-burst waiting process (SJF) | CO2 |
| 5 | Scheduling: highest-priority waiting process | CO2 |
| 6 | Preemptive priority scheduling | CO2 |
| 7 | Non-preemptive SJF | CO2 |
| 8 | Round Robin | CO2 |
| 9 | IPC – shared memory | CO3 |
| 10 | IPC – message queue | CO3 |
| 11 | Multithreading | CO3 |
| 12 | Dining philosophers | CO3 |
| 13 | Memory allocation strategies | CO3 |
| 14 | Single-level directory | CO3 |
| 15 | Two-level directory | CO3 |
| 16 | Random access file (employee records) | CO3 |
| 17 | Banker's algorithm | CO2 |
| 18 | Producer–consumer with semaphores | CO2 |
| 19 | Synchronization with mutex locks | CO2 |
| 20 | Reader–writer with semaphores | CO2 |
| 21 | Worst fit | CO3 |
| 22 | Best fit | CO3 |
| 23 | First fit | CO3 |
| 24 | UNIX file-management system calls | CO1 |
| 25 | I/O system calls (fcntl, lseek, stat, opendir, readdir) | CO5 |
| 26 | File management operations | CO4 |
| 27 | `ls` simulation | CO5 |
| 28 | `grep` simulation | CO5 |
| 29 | Classical synchronization problem (Sleeping Barber) | CO2 |
| 30 | Thread create / join / equal / exit | CO2 |
| 31 | FIFO page replacement | CO3 |
| 32 | LRU page replacement | CO3 |
| 33 | Optimal page replacement | CO3 |
| 34 | Sequential file allocation | CO4 |
| 35 | Indexed file allocation | CO4 |
| 36 | Linked file allocation | CO4 |
| 37 | FCFS disk scheduling | CO4 |
| 38 | SCAN disk scheduling | CO4 |
| 39 | C-SCAN disk scheduling | CO4 |
| 40 | Linux file access permissions and user types | CO4 |

> Experiments 12, 18, 20 and 29 use threads and timing, so the order of interleaved lines can differ slightly between runs.
