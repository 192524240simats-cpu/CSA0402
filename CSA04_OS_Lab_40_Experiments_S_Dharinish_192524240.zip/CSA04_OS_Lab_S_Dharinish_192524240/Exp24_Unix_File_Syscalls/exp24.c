/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 24. UNIX system calls for file management: open, write, lseek, read, stat, rename, unlink
 */
/* UNIX system calls for file management: open, write, lseek, read, stat, rename, unlink */
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
int main(void){
    const char *msg = "UNIX file management system calls";
    int fd = open("demo.txt", O_RDWR | O_CREAT | O_TRUNC, 0644);
    printf("open()   : file descriptor = %d\n", fd);
    ssize_t w = write(fd, msg, strlen(msg));
    printf("write()  : %zd bytes written\n", w);
    off_t pos = lseek(fd, 5, SEEK_SET);
    printf("lseek()  : offset moved to %ld\n", (long)pos);
    char buf[16] = {0}; ssize_t r = read(fd, buf, 4);
    printf("read()   : %zd bytes read -> \"%s\"\n", r, buf);
    struct stat st; fstat(fd, &st);
    printf("fstat()  : size = %ld bytes, mode = %o\n", (long)st.st_size, st.st_mode & 0777);
    close(fd); printf("close()  : file closed\n");
    rename("demo.txt", "renamed.txt"); printf("rename() : demo.txt -> renamed.txt\n");
    printf("access() : renamed.txt exists = %s\n", access("renamed.txt", F_OK) == 0 ? "yes" : "no");
    unlink("renamed.txt"); printf("unlink() : renamed.txt removed\n");
    printf("access() : renamed.txt exists = %s\n", access("renamed.txt", F_OK) == 0 ? "yes" : "no");
    return 0;
}
