/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 29. Classical synchronization problem: the Sleeping Barber (3 waiting chairs, 7 customers)
 */
/* Classical synchronization problem: the Sleeping Barber (3 waiting chairs, 7 customers) */
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <semaphore.h>
#define CHAIRS 3
#define CUST 7
sem_t customers, barber, mutex; int waiting = 0, done = 0, served = 0, left = 0;
void *barber_fn(void *a){ (void)a;
    for (;;) {
        sem_wait(&customers);
        if (done) break;
        sem_wait(&mutex); waiting--; sem_post(&barber); sem_post(&mutex);
        printf("   Barber is cutting hair\n"); fflush(stdout); usleep(350000); served++;
    }
    return NULL;
}
void *cust_fn(void *a){ int id = *(int *)a;
    sem_wait(&mutex);
    if (waiting < CHAIRS) {
        waiting++; printf("Customer %d sits in waiting room (%d waiting)\n", id, waiting); fflush(stdout);
        sem_post(&customers); sem_post(&mutex); sem_wait(&barber);
    } else { left++; printf("Customer %d finds no free chair and leaves\n", id); fflush(stdout); sem_post(&mutex); }
    return NULL;
}
int main(void){
    pthread_t b, c[CUST]; int id[CUST];
    sem_init(&customers, 0, 0); sem_init(&barber, 0, 0); sem_init(&mutex, 0, 1);
    pthread_create(&b, NULL, barber_fn, NULL);
    for (int i = 0; i < CUST; i++) { id[i] = i + 1; pthread_create(&c[i], NULL, cust_fn, &id[i]); usleep(100000); }
    for (int i = 0; i < CUST; i++) pthread_join(c[i], NULL);
    done = 1; sem_post(&customers); pthread_join(b, NULL);
    printf("Customers served: %d, left without haircut: %d\n", served, left);
    return 0;
}
