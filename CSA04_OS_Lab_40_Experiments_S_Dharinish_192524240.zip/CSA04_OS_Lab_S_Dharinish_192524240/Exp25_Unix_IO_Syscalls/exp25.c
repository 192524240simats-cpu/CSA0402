/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 25. I/O system calls: fcntl, lseek, stat, opendir, readdir
 */
/* I/O system calls: fcntl, lseek, stat, opendir, readdir */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>
static int cmp(const void *a, const void *b){ return strcmp(*(char *const *)a, *(char *const *)b); }
int main(void){
    mkdir("io_demo", 0755);
    const char *names[] = {"one.txt", "two.txt", "three.txt"};
    for (int i = 0; i < 3; i++) {
        char p[64]; snprintf(p, sizeof p, "io_demo/%s", names[i]);
        int f = open(p, O_WRONLY|O_CREAT|O_TRUNC, 0644);
        for (int k = 0; k <= i; k++) write(f, "0123456789", 10);
        close(f);
    }
    int fd = open("io_demo/one.txt", O_RDWR);
    int fl = fcntl(fd, F_GETFL);
    printf("fcntl(F_GETFL)  : access mode = %s\n", (fl & O_ACCMODE) == O_RDWR ? "O_RDWR" : "other");
    fcntl(fd, F_SETFL, fl | O_APPEND);
    printf("fcntl(F_SETFL)  : O_APPEND set = %s\n", (fcntl(fd, F_GETFL) & O_APPEND) ? "yes" : "no");
    printf("lseek(SEEK_END) : file size = %ld\n", (long)lseek(fd, 0, SEEK_END));
    lseek(fd, 3, SEEK_SET); char c; read(fd, &c, 1);
    printf("lseek(3)+read   : byte at offset 3 = '%c'\n", c);
    close(fd);
    struct stat st; stat("io_demo/three.txt", &st);
    printf("stat()          : three.txt size=%ld, links=%ld, regular=%s\n", (long)st.st_size, (long)st.st_nlink, S_ISREG(st.st_mode) ? "yes" : "no");
    DIR *d = opendir("io_demo"); struct dirent *e; char *list[16]; int n = 0;
    while ((e = readdir(d))) if (e->d_name[0] != '.') list[n++] = strdup(e->d_name);
    closedir(d); qsort(list, n, sizeof *list, cmp);
    printf("opendir/readdir : entries in io_demo =");
    for (int i = 0; i < n; i++) printf(" %s", list[i]);
    printf("\n");
    for (int i = 0; i < n; i++) { char p[64]; snprintf(p, sizeof p, "io_demo/%s", list[i]); unlink(p); free(list[i]); }
    rmdir("io_demo");
    return 0;
}
