/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 30. Thread concepts: (i) pthread_create (ii) pthread_join (iii) pthread_equal (iv) pthread_exit
 */
/* Thread concepts: (i) pthread_create (ii) pthread_join (iii) pthread_equal (iv) pthread_exit */
#include <stdio.h>
#include <pthread.h>
pthread_t saved;
void *task(void *arg){
    int n = *(int *)arg;
    printf("  [thread] running with argument %d\n", n);
    saved = pthread_self();
    pthread_exit((void *)(long)(n * n));          /* (iv) exit with a return value */
}
int main(void){
    pthread_t t1, t2; int a = 7, b = 9; void *ret;
    printf("(i) pthread_create:\n");
    pthread_create(&t1, NULL, task, &a);
    printf("(ii) pthread_join:\n");
    pthread_join(t1, &ret);
    printf("  thread returned %ld (7 squared)\n", (long)ret);
    printf("(iii) pthread_equal:\n");
    pthread_t first = saved;
    pthread_create(&t2, NULL, task, &b);
    pthread_join(t2, &ret);
    printf("  t1 and t1 equal? %s\n", pthread_equal(t1, t1) ? "yes" : "no");
    printf("  t1 and t2 equal? %s\n", pthread_equal(t1, t2) ? "yes" : "no");
    printf("  main thread equal to itself? %s\n", pthread_equal(pthread_self(), pthread_self()) ? "yes" : "no");
    (void)first;
    printf("(iv) pthread_exit used inside the threads; second thread returned %ld (9 squared)\n", (long)ret);
    return 0;
}
