/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 40. Linux file access permissions: owner / group / others, chmod, stat, access()
 */
/* Linux file access permissions: owner / group / others, chmod, stat, access() */
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>
static void sym(mode_t m, char *s){ const char *r = "rwxrwxrwx"; for (int i = 0; i < 9; i++) s[i] = (m & (1 << (8-i))) ? r[i] : '-'; s[9] = 0; }
static void show(const char *f){
    struct stat st; stat(f, &st); char s[10]; sym(st.st_mode, s);
    printf("%-9s mode %04o  %s   owner:%s group:%s others:%s   | access r=%s w=%s x=%s\n", f, st.st_mode & 07777, s,
           (st.st_mode & 0700) >> 6 == 7 ? "rwx" : "-", "-", "-",
           access(f, R_OK) == 0 ? "Y" : "N", access(f, W_OK) == 0 ? "Y" : "N", access(f, X_OK) == 0 ? "Y" : "N");
}
int main(void){
    printf("Types of users: owner (u), group (g), others (o).  Permissions: r=4, w=2, x=1\n");
    printf("Current process: uid=%d gid=%d\n", (int)getuid(), (int)getgid());
    if (getuid() == 0) printf("Note: running as root - root bypasses read/write permission checks (execute still needs an x bit).\n");
    printf("\n");
    int fd = open("perm_demo.txt", O_CREAT | O_WRONLY | O_TRUNC, 0644); write(fd, "demo", 4); close(fd);
    struct { mode_t m; const char *meaning; } t[] = {
        {0644, "owner rw-, group r--, others r--  (default for files)"},
        {0755, "owner rwx, group r-x, others r-x  (typical for programs)"},
        {0600, "owner rw-, group ---, others ---  (private file)"},
        {0444, "everyone read-only"},
        {0000, "no permissions for anyone"}};
    for (int i = 0; i < 5; i++) {
        chmod("perm_demo.txt", t[i].m);
        struct stat st; stat("perm_demo.txt", &st); char s[10]; sym(st.st_mode, s);
        printf("chmod %04o -> %s  %s\n", t[i].m, s, t[i].meaning);
        printf("    owner:%c%c%c  group:%c%c%c  others:%c%c%c   | for current user: read=%s write=%s exec=%s\n",
               s[0],s[1],s[2],s[3],s[4],s[5],s[6],s[7],s[8],
               access("perm_demo.txt", R_OK) == 0 ? "yes" : "no", access("perm_demo.txt", W_OK) == 0 ? "yes" : "no", access("perm_demo.txt", X_OK) == 0 ? "yes" : "no");
    }
    chmod("perm_demo.txt", 0644); unlink("perm_demo.txt");
    (void)show;
    return 0;
}
