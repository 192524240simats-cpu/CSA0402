/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 37. FCFS disk scheduling
 */
/* FCFS disk scheduling */
#include <stdio.h>
#include <stdlib.h>
int main(void){
    int q[] = {98, 183, 37, 122, 14, 124, 65, 67}, n = 8, head = 53, total = 0;
    printf("Request queue: "); for (int i = 0; i < n; i++) printf("%d ", q[i]);
    printf("\nInitial head position: %d\n\nSeek sequence:\n%d", head, head);
    for (int i = 0; i < n; i++) { total += abs(q[i] - head); printf(" -> %d", q[i]); head = q[i]; }
    printf("\n\nTotal head movement = %d cylinders\nAverage seek length = %.2f\n", total, (float)total / n);
    return 0;
}
