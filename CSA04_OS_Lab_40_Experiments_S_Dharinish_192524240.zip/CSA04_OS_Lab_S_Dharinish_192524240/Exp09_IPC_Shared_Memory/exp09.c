/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 9. Inter-process communication using System V shared memory
 */
/* Inter-process communication using System V shared memory */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
int main(void){
    setvbuf(stdout, NULL, _IOLBF, 0);   /* line-buffered so fork() does not duplicate output */
    int id = shmget(IPC_PRIVATE, 1024, IPC_CREAT | 0666);
    if (id < 0) { perror("shmget"); return 1; }
    char *mem = shmat(id, NULL, 0);
    strcpy(mem, "Hello from parent via shared memory");
    printf("[Parent] wrote : %s\n", mem);
    pid_t pid = fork();
    if (pid == 0) {
        printf("[Child ] read  : %s\n", mem);
        strcpy(mem, "Reply from child via shared memory");
        shmdt(mem); exit(0);
    }
    wait(NULL);
    printf("[Parent] read  : %s\n", mem);
    shmdt(mem);
    shmctl(id, IPC_RMID, NULL);
    printf("Shared memory segment removed.\n");
    return 0;
}
