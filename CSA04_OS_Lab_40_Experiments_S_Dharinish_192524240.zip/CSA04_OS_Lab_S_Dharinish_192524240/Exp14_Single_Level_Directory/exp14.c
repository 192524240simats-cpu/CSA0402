/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 14. Single-level directory: all files of all users live in ONE directory
 */
/* Single-level directory: all files of all users live in ONE directory */
#include <stdio.h>
#include <string.h>
#define MAX 10
char dir[MAX][20]; int count = 0;
void create(const char *f){
    for (int i = 0; i < count; i++) if (!strcmp(dir[i], f)) { printf("create %-10s : name already exists\n", f); return; }
    if (count == MAX) { printf("directory full\n"); return; }
    strcpy(dir[count++], f); printf("create %-10s : file created\n", f);
}
void search(const char *f){
    for (int i = 0; i < count; i++) if (!strcmp(dir[i], f)) { printf("search %-10s : found at entry %d\n", f, i+1); return; }
    printf("search %-10s : not found\n", f);
}
void del(const char *f){
    for (int i = 0; i < count; i++) if (!strcmp(dir[i], f)) {
        for (int j = i; j < count-1; j++) strcpy(dir[j], dir[j+1]);
        count--; printf("delete %-10s : file deleted\n", f); return; }
    printf("delete %-10s : not found\n", f);
}
void list(void){
    printf("Directory listing (%d files):\n", count);
    for (int i = 0; i < count; i++) printf("  %d. %s\n", i+1, dir[i]);
}
int main(void){
    create("a.txt"); create("b.txt"); create("prog.c"); create("a.txt");
    list(); search("b.txt"); search("x.doc");
    del("a.txt"); del("zzz"); list();
    return 0;
}
