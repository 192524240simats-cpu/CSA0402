/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 8. Round Robin scheduling, time quantum = 3 (all arrive at time 0)
 */
/* Round Robin scheduling, time quantum = 3 (all arrive at time 0) */
#include <stdio.h>
int main(void){
    int n = 5, bt[] = {10,5,8,6,3}, rem[5], wt[5], tat[5], q = 3, t = 0, left = 5;
    float tw = 0, tt = 0;
    for (int i = 0; i < n; i++) rem[i] = bt[i];
    printf("Time quantum = %d\nExecution trace:\n", q);
    while (left > 0) {
        for (int i = 0; i < n; i++) {
            if (rem[i] == 0) continue;
            int run = rem[i] < q ? rem[i] : q;
            printf("t=%2d..%2d: P%d\n", t, t+run, i+1);
            t += run; rem[i] -= run;
            if (rem[i] == 0) { tat[i] = t; wt[i] = t - bt[i]; left--; }
        }
    }
    printf("\nProcess\tBurst\tWaiting\tTurnaround\n");
    for (int i = 0; i < n; i++) {
        tw += wt[i]; tt += tat[i];
        printf("P%d\t%d\t%d\t%d\n", i+1, bt[i], wt[i], tat[i]);
    }
    printf("Average waiting time    = %.2f\nAverage turnaround time = %.2f\n", tw/n, tt/n);
    return 0;
}
