/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 10. Inter-process communication using a System V message queue
 */
/* Inter-process communication using a System V message queue */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>
struct msg { long type; char text[64]; };
int main(void){
    setvbuf(stdout, NULL, _IOLBF, 0);   /* line-buffered so fork() does not duplicate output */
    int q = msgget(IPC_PRIVATE, IPC_CREAT | 0666);
    if (q < 0) { perror("msgget"); return 1; }
    pid_t pid = fork();
    if (pid == 0) {
        struct msg m;
        for (int i = 0; i < 3; i++) {
            msgrcv(q, &m, sizeof m.text, 0, 0);
            printf("[Child ] received (type %ld): %s\n", m.type, m.text);
        }
        exit(0);
    }
    const char *words[] = {"First message", "Second message", "Third message"};
    for (int i = 0; i < 3; i++) {
        struct msg m = { i + 1, "" };
        strcpy(m.text, words[i]);
        msgsnd(q, &m, strlen(m.text) + 1, 0);
        printf("[Parent] sent     (type %ld): %s\n", m.type, m.text);
    }
    wait(NULL);
    msgctl(q, IPC_RMID, NULL);
    printf("Message queue removed.\n");
    return 0;
}
