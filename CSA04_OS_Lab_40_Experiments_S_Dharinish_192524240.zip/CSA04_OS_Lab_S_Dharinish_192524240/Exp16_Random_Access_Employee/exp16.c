/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 16. Random access file: employee records accessed directly with fseek()
 */
/* Random access file: employee records accessed directly with fseek() */
#include <stdio.h>
#include <string.h>
struct emp { int id; char name[20]; char dept[12]; float salary; };
int main(void){
    struct emp e[] = {{101,"Arun","Sales",32000},{102,"Bala","IT",45000},{103,"Chitra","HR",38000},
                      {104,"Divya","IT",52000},{105,"Elan","Finance",41000}};
    FILE *f = fopen("employees.dat", "wb+");
    fwrite(e, sizeof(struct emp), 5, f);
    printf("5 employee records written (record size = %zu bytes)\n\n", sizeof(struct emp));
    struct emp r;
    fseek(f, 2 * sizeof(struct emp), SEEK_SET);            /* direct access: record 3 */
    fread(&r, sizeof r, 1, f);
    printf("Direct read of record 3: %d %s %s %.2f\n", r.id, r.name, r.dept, r.salary);
    fseek(f, 1 * sizeof(struct emp), SEEK_SET);            /* update record 2 */
    fread(&r, sizeof r, 1, f);
    r.salary += 5000;
    fseek(f, 1 * sizeof(struct emp), SEEK_SET);
    fwrite(&r, sizeof r, 1, f);
    printf("Record 2 salary raised by 5000.\n\nAll records:\n");
    rewind(f);
    printf("ID\tName\tDept\tSalary\n");
    while (fread(&r, sizeof r, 1, f) == 1) printf("%d\t%s\t%s\t%.2f\n", r.id, r.name, r.dept, r.salary);
    fclose(f); remove("employees.dat");
    return 0;
}
