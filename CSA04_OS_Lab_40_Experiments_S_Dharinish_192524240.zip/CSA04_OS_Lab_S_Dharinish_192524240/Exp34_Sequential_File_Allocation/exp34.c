/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 34. Sequential file allocation: a file occupies contiguous blocks; records are read in order
 */
/* Sequential file allocation: a file occupies contiguous blocks; records are read in order */
#include <stdio.h>
#include <string.h>
#define BLOCKS 30
int disk[BLOCKS];                  /* 0 = free, otherwise file number */
struct file { char name[12]; int start, len; } f[10]; int nf = 0;
int allocate(const char *name, int len){
    for (int s = 0; s + len <= BLOCKS; s++) {
        int ok = 1;
        for (int k = 0; k < len; k++) if (disk[s+k]) { ok = 0; break; }
        if (ok) { strcpy(f[nf].name, name); f[nf].start = s; f[nf].len = len; nf++;
                  for (int k = 0; k < len; k++) disk[s+k] = nf;
                  return 1; }
    }
    return 0;
}
int main(void){
    const char *nm[] = {"mail", "count", "tr", "list", "huge"}; int ln[] = {5, 6, 3, 4, 20};
    for (int i = 0; i < 5; i++)
        if (!allocate(nm[i], ln[i])) printf("File %-6s (%2d blocks): no contiguous space available\n", nm[i], ln[i]);
    printf("\nDirectory\nFile\tStart\tLength\tBlocks\n");
    for (int i = 0; i < nf; i++) {
        printf("%s\t%d\t%d\t%d-%d\n", f[i].name, f[i].start, f[i].len, f[i].start, f[i].start + f[i].len - 1);
    }
    printf("\nSequential access of file '%s' (record i needs all previous records read):\n", f[1].name);
    for (int r = 0; r < f[1].len; r++) printf("  read record %d -> block %d  (records read so far: %d)\n", r+1, f[1].start + r, r+1);
    printf("\nDisk map: "); for (int i = 0; i < BLOCKS; i++) printf("%d", disk[i]); printf("\n");
    return 0;
}
