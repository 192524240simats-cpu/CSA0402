/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 11. Multithreading with POSIX threads: three threads do independent work
 */
/* Multithreading with POSIX threads: three threads do independent work */
#include <stdio.h>
#include <pthread.h>
struct job { int id; long result; };
void *sum_n(void *a){ struct job *j = a; long s = 0; for (int i = 1; i <= 100; i++) s += i; j->result = s; return NULL; }
void *fact(void *a){ struct job *j = a; long f = 1; for (int i = 2; i <= 10; i++) f *= i; j->result = f; return NULL; }
void *squares(void *a){ struct job *j = a; long s = 0; for (int i = 1; i <= 10; i++) s += (long)i*i; j->result = s; return NULL; }
int main(void){
    pthread_t t[3]; struct job j[3] = {{1,0},{2,0},{3,0}};
    void *(*fn[3])(void *) = { sum_n, fact, squares };
    const char *what[] = {"Sum of 1..100", "Factorial of 10", "Sum of squares 1..10"};
    for (int i = 0; i < 3; i++) pthread_create(&t[i], NULL, fn[i], &j[i]);
    for (int i = 0; i < 3; i++) pthread_join(t[i], NULL);
    for (int i = 0; i < 3; i++) printf("Thread %d: %-22s = %ld\n", j[i].id, what[i], j[i].result);
    printf("All threads finished; main thread continues.\n");
    return 0;
}
