/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 17. Deadlock avoidance: Banker's algorithm (safety check + resource request)
 */
/* Deadlock avoidance: Banker's algorithm (safety check + resource request) */
#include <stdio.h>
#define P 5
#define R 3
int alloc[P][R] = {{0,1,0},{2,0,0},{3,0,2},{2,1,1},{0,0,2}};
int max[P][R]   = {{7,5,3},{3,2,2},{9,0,2},{2,2,2},{4,3,3}};
int avail[R]    = {3,3,2};
int need[P][R];
int is_safe(int *seq){
    int work[R], fin[P] = {0}, c = 0;
    for (int j = 0; j < R; j++) work[j] = avail[j];
    while (c < P) {
        int found = 0;
        for (int i = 0; i < P; i++) {
            if (fin[i]) continue;
            int ok = 1;
            for (int j = 0; j < R; j++) if (need[i][j] > work[j]) { ok = 0; break; }
            if (ok) { for (int j = 0; j < R; j++) work[j] += alloc[i][j]; seq[c++] = i; fin[i] = 1; found = 1; }
        }
        if (!found) return 0;
    }
    return 1;
}
int main(void){
    int seq[P];
    for (int i = 0; i < P; i++) for (int j = 0; j < R; j++) need[i][j] = max[i][j] - alloc[i][j];
    printf("Process  Allocation  Max    Need\n");
    for (int i = 0; i < P; i++) {
        printf("P%d       ", i);
        for (int j = 0; j < R; j++) printf("%d ", alloc[i][j]);
        printf("      ");
        for (int j = 0; j < R; j++) printf("%d ", max[i][j]);
        printf("  ");
        for (int j = 0; j < R; j++) printf("%d ", need[i][j]);
        printf("\n");
    }
    printf("Available: %d %d %d\n\n", avail[0], avail[1], avail[2]);
    if (is_safe(seq)) { printf("System is in a SAFE state.\nSafe sequence: "); for (int i = 0; i < P; i++) printf("P%d%s", seq[i], i < P-1 ? " -> " : "\n"); }
    else printf("System is NOT in a safe state.\n");
    /* P1 requests (1,0,2) */
    int req[R] = {1,0,2}, p = 1, ok = 1;
    printf("\nP%d requests (%d,%d,%d): ", p, req[0], req[1], req[2]);
    for (int j = 0; j < R; j++) if (req[j] > need[p][j] || req[j] > avail[j]) ok = 0;
    if (ok) {
        for (int j = 0; j < R; j++) { avail[j] -= req[j]; alloc[p][j] += req[j]; need[p][j] -= req[j]; }
        if (is_safe(seq)) { printf("granted (state stays safe). Safe sequence: "); for (int i = 0; i < P; i++) printf("P%d ", seq[i]); printf("\n"); }
        else printf("denied (would be unsafe)\n");
    } else printf("must wait (exceeds need or availability)\n");
    return 0;
}
