/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 26. File management operations with the C library: create, write, append, read, copy, rename, size, delete
 */
/* File management operations with the C library: create, write, append, read, copy, rename, size, delete */
#include <stdio.h>
#include <stdlib.h>
int main(void){
    FILE *f = fopen("file1.txt", "w");
    fprintf(f, "Line 1: created file\n"); fclose(f);
    printf("1. File created and written\n");
    f = fopen("file1.txt", "a"); fprintf(f, "Line 2: appended text\n"); fclose(f);
    printf("2. Text appended\n");
    printf("3. Reading file1.txt:\n");
    f = fopen("file1.txt", "r"); char line[100];
    while (fgets(line, sizeof line, f)) printf("   %s", line);
    fseek(f, 0, SEEK_END); printf("4. File size = %ld bytes\n", ftell(f));
    rewind(f);
    FILE *g = fopen("file2.txt", "w"); int ch;
    while ((ch = fgetc(f)) != EOF) fputc(ch, g);
    fclose(f); fclose(g); printf("5. file1.txt copied to file2.txt\n");
    rename("file2.txt", "copy.txt"); printf("6. file2.txt renamed to copy.txt\n");
    printf("7. Deleting files: file1.txt %s, copy.txt %s\n",
           remove("file1.txt") == 0 ? "deleted" : "failed", remove("copy.txt") == 0 ? "deleted" : "failed");
    return 0;
}
