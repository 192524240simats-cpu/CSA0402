/*
 * Name        : S Dharinish
 * Register No : 192524240
 * Course      : CSA04 - Operating Systems Lab
 * Experiment  : 38. SCAN (elevator) disk scheduling: head moves toward higher cylinders first, then reverses
 */
/* SCAN (elevator) disk scheduling: head moves toward higher cylinders first, then reverses */
#include <stdio.h>
#include <stdlib.h>
int main(void){
    int q[] = {98, 183, 37, 122, 14, 124, 65, 67}, n = 8, head = 53, disk = 200, total = 0;
    for (int i = 0; i < n-1; i++) for (int j = 0; j < n-i-1; j++) if (q[j] > q[j+1]) { int t = q[j]; q[j] = q[j+1]; q[j+1] = t; }
    printf("Disk cylinders: 0-%d, head at %d, direction: towards %d\n\nSeek sequence:\n%d", disk-1, head, disk-1, head);
    int pos = head;
    for (int i = 0; i < n; i++) if (q[i] >= head) { total += abs(q[i] - pos); pos = q[i]; printf(" -> %d", pos); }
    total += abs(disk - 1 - pos); pos = disk - 1; printf(" -> %d", pos);
    for (int i = n-1; i >= 0; i--) if (q[i] < head) { total += abs(q[i] - pos); pos = q[i]; printf(" -> %d", pos); }
    printf("\n\nTotal head movement = %d cylinders\n", total);
    return 0;
}
